setwd("C:/Users/Irina/Disk Google/1_ČZU/Sucho")
u = readRDS('data/uzivani.rds')
u = u[complete.cases(X, Y)]

kp = spTransform(povodi_0, CRS("+init=epsg:2065"))

require(rgeos)

xy = SpatialPoints(u[, .(X, Y)])

i = 1

kde = gIntersects(kp[i,], xy, byid = TRUE)
neco <- u[kde[,1], ]

